package sv.edu.udb.panventury_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PanventuryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PanventuryServiceApplication.class, args);
	}

}

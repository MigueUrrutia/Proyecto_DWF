package sv.edu.udb.panventury_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sv.edu.udb.panventury_service.model.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {}
